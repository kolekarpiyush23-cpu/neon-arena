const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "public")));

const rooms = new Map();
const COLORS = ["#66e3ff", "#ff5f9e", "#a7ff83", "#ffd166", "#bca7ff", "#ff9566"];
function roomState(code) {
  if (!rooms.has(code)) rooms.set(code, { players: {}, target: null, roundEnds: 0, started: false });
  return rooms.get(code);
}
function publicState(room) {
  return {
    players: Object.values(room.players),
    target: room.target,
    started: room.started,
    roundEnds: room.roundEnds
  };
}
function newTarget() {
  return { x: 70 + Math.random() * 660, y: 80 + Math.random() * 360, r: 15 };
}
io.on("connection", socket => {
  socket.on("joinRoom", ({ code, name }) => {
    code = String(code || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
    name = String(name || "Player").trim().slice(0, 18) || "Player";
    if (!code) return socket.emit("notice", "Enter a room code.");
    if (socket.data.room) {
      const old = rooms.get(socket.data.room);
      if (old) { delete old.players[socket.id]; io.to(socket.data.room).emit("state", publicState(old)); }
      socket.leave(socket.data.room);
    }
    const room = roomState(code);
    room.players[socket.id] = {
      id: socket.id, name, color: COLORS[Object.keys(room.players).length % COLORS.length],
      x: 120 + Math.random() * 500, y: 120 + Math.random() * 250, score: 0
    };
    socket.data.room = code;
    socket.join(code);
    socket.emit("joined", { code, id: socket.id });
    io.to(code).emit("state", publicState(room));
    io.to(code).emit("notice", `${name} joined the arena.`);
  });
  socket.on("move", ({x,y}) => {
    const room = rooms.get(socket.data.room);
    const p = room && room.players[socket.id];
    if (!p || !Number.isFinite(x) || !Number.isFinite(y)) return;
    p.x = Math.max(20, Math.min(780, x)); p.y = Math.max(20, Math.min(500, y));
    io.to(socket.data.room).emit("state", publicState(room));
  });
  socket.on("startRound", () => {
    const room = rooms.get(socket.data.room);
    if (!room) return;
    room.started = true; room.target = newTarget(); room.roundEnds = Date.now() + 60000;
    io.to(socket.data.room).emit("state", publicState(room));
    io.to(socket.data.room).emit("notice", "Round started! Collect the glowing orbs.");
  });
  socket.on("collect", () => {
    const code = socket.data.room, room = rooms.get(code), p = room && room.players[socket.id];
    if (!p || !room.started || !room.target || Date.now() > room.roundEnds) return;
    const dx = p.x - room.target.x, dy = p.y - room.target.y;
    if (dx*dx + dy*dy < 42*42) {
      p.score += 1; room.target = newTarget();
      io.to(code).emit("state", publicState(room));
      io.to(code).emit("notice", `${p.name} collected an orb!`);
    }
  });
  socket.on("disconnect", () => {
    const code = socket.data.room, room = rooms.get(code);
    if (room) {
      const name = room.players[socket.id]?.name || "A player";
      delete room.players[socket.id];
      io.to(code).emit("state", publicState(room));
      io.to(code).emit("notice", `${name} left the arena.`);
      if (!Object.keys(room.players).length) rooms.delete(code);
    }
  });
});
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Neon Arena running on http://localhost:${PORT}`));
